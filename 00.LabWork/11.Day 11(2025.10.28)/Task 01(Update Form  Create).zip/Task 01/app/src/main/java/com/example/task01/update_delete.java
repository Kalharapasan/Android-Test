package com.example.task01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class update_delete extends AppCompatActivity {
    Button update,delete,back;
    EditText id,name,emil,age,address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        back=findViewById(R.id.buttonBack);
        update=findViewById(R.id.buttonUpdate);
        delete=findViewById(R.id.buttonDelete);
        id =findViewById(R.id.editTextID);
        name =findViewById(R.id.editTextName);
        emil =findViewById(R.id.editTextEmail);
        age =findViewById(R.id.editTextAge);
        address =findViewById(R.id.editTextAddress);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(update_delete.this,MainActivity.class);
                startActivity(intent);
            }
        });



    }
}